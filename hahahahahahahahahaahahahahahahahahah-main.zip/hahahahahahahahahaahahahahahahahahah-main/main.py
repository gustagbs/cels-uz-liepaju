print('Spēle “Tūrisma rallijs Liepāja 2022” ')
print('AUTORI: Gustavs Judeiks, Ronalds Gackis')
print('wwhvhwvhhwmp mphowehbmimo mwh ijiwo noteikumi')